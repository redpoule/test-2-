# Discord Savegame Bot

Ce dépôt envoie automatiquement un fichier de sauvegarde sur Discord toutes les heures via GitHub Actions.